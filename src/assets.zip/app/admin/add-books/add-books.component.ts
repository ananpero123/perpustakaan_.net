import { Component } from '@angular/core';
import { Firestore, collection, addDoc } from '@angular/fire/firestore';

@Component({
  selector: 'app-add-books',
  templateUrl: './add-books.component.html',
  styleUrls: ['./add-books.component.css']
})
export class AddBooksComponent {
  title = 'perpustakaan';
  bookData = {
    title: '',
    author: '',
    publisher: '',
    isbn: '',
    category: '',
    coverImage: null,
    bookPdf: null


  };

  constructor(private firestore: Firestore) {}

  addBook() {
    const collectionInstance = collection(this.firestore, 'book');
    addDoc(collectionInstance, this.bookData)
      .then(() => {
        console.log('Book added successfully');
        this.resetForm();
      })
      .catch((err) => {
        console.log(err);
      });
  }

  resetForm() {
    this.bookData = {
      title: '',
      author: '',
      publisher: '',
      isbn: '',
      category: '',
      coverImage: null,
      bookPdf: null
    };
  }

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.bookData.coverImage = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  onPdfFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.bookData.bookPdf = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }
}
