  import { Component, OnInit } from '@angular/core';
  import { AngularFireAuth } from '@angular/fire/compat/auth';
  import { getFirestore, doc, getDoc, updateDoc } from 'firebase/firestore';

  @Component({
      selector: 'app-edit',
      templateUrl: './edit.component.html',
      styleUrls: ['./edit.component.css']
  })
  export class EditComponent implements OnInit {
      userUid: string | null = null;
      firstName: string = '';
      lastName: string = '';
      username: string = '';
      email: string = '';
      address: string = '';
      phone: string = '';
      imageProfile: string | undefined;

      constructor(private afAuth: AngularFireAuth) {}

      ngOnInit() {
          this.afAuth.authState.subscribe(user => {
              if (user) {
                  this.userUid = user.uid;
                  const firestoreInstance = getFirestore();
                  const userDocRef = doc(firestoreInstance, 'users', this.userUid);

                  getDoc(userDocRef).then((userDoc) => {
                      if (userDoc.exists()) {
                          const userData = userDoc.data() as any;
                          this.firstName = userData.firstName;
                          this.lastName = userData.lastName;
                          this.username = userData.username;
                          this.email = userData.email;
                          this.address = userData.address;
                          this.phone = userData.phone;
                          this.imageProfile = userData.imageProfile;
                      }
                  });
              }
          });
      }

      handleImageUpload(event: any) {
          const file = event.target.files[0];
          if (file) {
              const reader = new FileReader();
              reader.onload = () => {
                  this.imageProfile = reader.result as string;
              };
              reader.readAsDataURL(file);
          }
      }

      saveChanges() {
        if (this.userUid) {
            const firestoreInstance = getFirestore();
            const userDocRef = doc(firestoreInstance, 'users', this.userUid);
    
            // Membuat objek data yang akan diupdate
            const updatedData = {
                firstName: this.firstName,
                lastName: this.lastName,
                username: this.username,
                email: this.email,
                address: this.address,
                phone: this.phone,
                imageProfile: this.imageProfile // Menggunakan base64 imageProfile yang sudah diupload
            };
    
            // Menggunakan updateDoc untuk mengupdate data ke Firestore
            updateDoc(userDocRef, updatedData)
                .then(() => {
                    console.log('Data updated successfully');
                    this.refreshPage(); // Memanggil fungsi refreshPage setelah berhasil menyimpan perubahan
                })
                .catch((error) => {
                    console.error('Error updating data:', error);
                });
        }
    }
    
    refreshPage() {
        setTimeout(() => {
            window.location.reload();
        }, 100); // Menunggu 100ms sebelum merefresh halaman
    }
}