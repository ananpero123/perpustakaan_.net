import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'; 
import { Firestore, doc, getDoc, updateDoc } from '@angular/fire/firestore'; 

@Component({
  selector: 'app-edit-books',
  templateUrl: './edit-books.component.html',
  styleUrls: ['./edit-books.component.css']
})
export class EditBooksComponent implements OnInit {
  bookId: string | null = null;
  bookData: any = {
    title: '',
    author: '',
    publisher: '',
    isbn: '',
    category: '',
    coverImage: null,
    bookPdf: null
  };

  constructor(private firestore: Firestore, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      this.bookId = params.get('id');
      if (this.bookId) {
        this.loadBookData(this.bookId);
      }
    });
  }

  loadBookData(bookId: string): void {
    const docRef = doc(this.firestore, 'book', bookId);

    getDoc(docRef)
      .then((docSnap) => {
        if (docSnap.exists()) {
          this.bookData = docSnap.data();
        } else {
          console.log('Document not found');
        }
      })
      .catch((error) => {
        console.error('Error getting document:', error);
      });
  }

  updateBook(): void {
    if (this.bookId) {
      const docRef = doc(this.firestore, 'book', this.bookId);

      updateDoc(docRef, this.bookData)
        .then(() => {
          console.log('Book updated successfully');
        })
        .catch((error) => {
          console.error('Error updating document:', error);
        });
    }
  } 

  onFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      // Baca file gambar sebagai URL data
      const reader = new FileReader();
      reader.onload = (e) => {
        this.bookData.coverImage = e.target?.result;
      };
      reader.readAsDataURL(file);
    }
  }

  onPdfFileChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      // Baca file PDF sebagai URL data
      const reader = new FileReader();
      reader.onload = (e) => {
        this.bookData.bookPdf = e.target?.result;
      };
      reader.readAsDataURL(file);
    }
  }
}

