import { Component } from '@angular/core';

@Component({
  selector: 'app-libraryku',
  templateUrl: './libraryku.component.html',
  styleUrls: ['./libraryku.component.css']
})
export class LibrarykuComponent {

}
