export const environment = {
  firebase: {
    projectId: 'perpustakaan-efc56',
    appId: '1:365504328585:web:153bf0e2f627c19224e758',
    storageBucket: 'perpustakaan-efc56.appspot.com',
    apiKey: 'AIzaSyBPwpmm7jnsf-mRkMj5fJ5dEVuIuOnLjs8',
    authDomain: 'perpustakaan-efc56.firebaseapp.com',
    messagingSenderId: '365504328585',
  },
};